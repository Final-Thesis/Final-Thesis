//
//  MilestoneDetailView.swift
//  IColab
//
//  Created by Jeremy Raymond on 24/09/23.
//

import SwiftUI

struct MilestoneDetailView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct MilestoneDetailView_Previews: PreviewProvider {
    static var previews: some View {
        MilestoneDetailView()
    }
}
