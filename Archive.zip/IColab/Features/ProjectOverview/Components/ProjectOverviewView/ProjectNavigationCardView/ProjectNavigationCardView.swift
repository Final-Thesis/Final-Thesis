//
//  ProjectNavigationCardView.swift
//  IColab
//
//  Created by Jeremy Raymond on 27/09/23.
//

import SwiftUI

struct ProjectNavigationCardView: View {
    @EnvironmentObject var vm: ProjectOverviewViewModel
    
    var body: some View {
        VStack {
                NavigationLink {
                    ProjectDescriptionView(project: Mock.projects[0])
                        .environmentObject(vm)
                } label: {
                    ProjectButtonView(
                        icon: "newspaper.circle",
                        title: "Project Description",
                        description: "Get in depth overview of the current project, it's requirements, and summary"
                    )
                }
                NavigationLink {
                    ContactListView()
                } label: {
                    ProjectButtonView(
                        icon: "envelope.circle",
                        title: "Contact",
                        description: "See member of the project and contact them"
                    )
                }
                NavigationLink {
                    MilestonesView()
                } label: {
                    ProjectButtonView(
                        icon: "star.circle",
                        title: "Milestone",
                        description: "See how far the project have gone, and details about the milestones"
                    )
                }
                NavigationLink {
                    ResourceRequirementView()
                } label: {
                    ProjectButtonView(
                        icon: "folder.circle",
                        title: "Resource Requirements",
                        description: "Information on the personnel, equipment, materials, and budget needed to complete the project."
                    )
                }
                NavigationLink {
                    CurrentTaskView()
                } label: {
                    ProjectButtonView(
                        icon: "bag.circle",
                        title: "Current Task",
                        description: "Current project or task that must be done according to the deadline"
                    )
                }
                
            }
        }
    }

#Preview {
    ProjectNavigationCardView()
}
