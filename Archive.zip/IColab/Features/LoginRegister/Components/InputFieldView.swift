//
//  InputFieldView.swift
//  IColab
//
//  Created by Jeremy Raymond on 01/10/23.
//

import SwiftUI

struct InputFieldView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

#Preview {
    InputFieldView()
}
