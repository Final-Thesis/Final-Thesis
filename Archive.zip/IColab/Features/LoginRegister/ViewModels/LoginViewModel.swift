//
//  LoginViewModel.swift
//  IColab
//
//  Created by Brandon Nicolas Marlim on 10/2/23.
//

import Foundation

class LoginViewModel: ObservableObject {
  @Published var email = ""
  @Published var password = ""

//  func login() {
//    if let account = MockAccounts.accounts.first(where: { $0.email == email && $0.password == password }) {
//
//    } else {
//    
//    }
//  }
}
