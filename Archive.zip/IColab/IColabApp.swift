//
//  IColabApp.swift
//  IColab
//
//  Created by Brandon Nicolas Marlim on 7/30/23.
//

import SwiftUI

@main
struct IColabApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
