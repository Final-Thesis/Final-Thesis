//
//  Member.swift
//  IColab
//
//  Created by Jeremy Raymond on 01/10/23.
//

import Foundation

struct Member {
    var account: Account
    var role: Role
}
